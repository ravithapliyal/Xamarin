﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App1
{
    public class Types
    {
        public string ControlType { get; set; }
        public string LabelEnglish { get; set; }
        public string LabelArabic { get; set; }
        public string IsCompulsary { get; set; }

    }
}
