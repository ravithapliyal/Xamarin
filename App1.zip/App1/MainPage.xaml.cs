﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace App1
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void SaveButton_Clicked(object sender, EventArgs e)
        {
            var items = new Types { ControlType = controltype.SelectedItem.ToString(), LabelEnglish = english.Text, LabelArabic = arabic.Text };
            MainViewModel mainViewModel = new MainViewModel();
            mainViewModel.Types.Add(items);
            Navigation.PushAsync(new ListPage());
        }
    }
}
